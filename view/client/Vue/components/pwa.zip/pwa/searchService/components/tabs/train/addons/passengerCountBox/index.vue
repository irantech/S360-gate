<template>
   <div class="select position-unset inp-s-num adt box-of-count-nafar">
      <div
         @click="form[strategy].options.passengers_number = true"
         class="box-of-count-nafar-boxes">
         <span class="text-count-nafar">
            {{ form[strategy].passengers_number.adult.value }} بزرگسال ,
            {{ form[strategy].passengers_number.child.value }} کودک ,
            {{ form[strategy].passengers_number.infant.value }} نوزاد
         </span>
         <span class="fas fa-caret-down down-count-nafar"></span>
      </div>
      <div
         @click.self="accept_data"
         class="fixed-black"
         :class="form[strategy].options.passengers_number ? 'active' : ''">
         <div
            class="cbox-count-nafar p-3"
            :class="form[strategy].options.passengers_number ? 'active' : ' '">
            <div class="col-md-12 mb-3 p-0">
               <h3 class="font-weight-bold m-0 font-19">مسافران</h3>
            </div>

            <div
               v-for="passenger_index in passengers_index"
               class="col-md-12 p-0 bozorg-num mb-2">
               <div
                  class="align-items-center d-flex flex-wrap justify-content-between row">
                  <div class="d-flex p-0">
                     <div class="type-of-count-nafar">
                        <h6>{{ passenger_index.title }}</h6>
                        <span class="text-muted">
                           {{ passenger_index.text }}
                        </span>
                     </div>
                  </div>
                  <div class="d-flex p-0">
                     <div class="num-of-count-nafar">
                        <i
                           @click="increaseCount(passenger_index.index)"
                           :class="
                              canAdd(passenger_index.index, false)
                                 ? ''
                                 : 'opacity-5'
                           "
                           class="fas fa-plus m-0 counting-of-count-nafar site-bg-main-color"></i>
                        <i
                           class="number-count counting-of-count-nafar"
                           data-value="l-bozorgsal"
                           id="bozorgsal"
                           >{{
                              form[strategy].passengers_number[
                                 passenger_index.index
                              ].value
                           }}</i
                        >
                        <i
                           @click="decreaseCount(passenger_index.index)"
                           :class="
                              form[strategy].passengers_number[
                                 passenger_index.index
                              ].value <=
                              form[strategy].passengers_number[
                                 passenger_index.index
                              ].min
                                 ? 'opacity-5'
                                 : ''
                           "
                           class="fas fa-minus m-0 counting-of-count-nafar minus-nafar site-bg-main-color"></i>
                     </div>
                  </div>
               </div>
            </div>

            <div class="col-md-12 p-0 bozorg-num mb-2 mt-2">
               <div
                  class="btn-group w-100 d-flex flex-row-reverse btn-group-toggle"
                  data-toggle="buttons">
                  <label
                     v-for="(passenger_seat_type, key) in passengers_seat_type"
                     @click="changeSeatType(passenger_seat_type.index)"
                     class="btn btn-new"
                     :class="
                        form[strategy].passengers_number.seat_type ===
                        passenger_seat_type.index
                           ? 'active site-bg-main-color'
                           : ''
                     ">
                     <input
                        type="radio"
                        name="options"
                        :id="'option' + key"
                        autocomplete="off" />
                     {{ passenger_seat_type.title }}
                  </label>
               </div>
            </div>

            <div class="col-md-12 p-0 bozorg-num mb-2">
               <div
                  class="btn-group w-100 d-flex flex-row-reverse btn-group-toggle"
                  data-toggle="buttons">
                  <label
                     v-for="(
                        passenger_coupe_type, key
                     ) in passengers_coupe_type"
                     @click="changeCoupeType(passenger_coupe_type.index)"
                     class="btn btn-new"
                     :class="
                        form[strategy].passengers_number.dedicated_coupe ===
                        passenger_coupe_type.index
                           ? 'active site-bg-main-color'
                           : ''
                     ">
                     <input
                        type="radio"
                        name="options"
                        :id="'optionType' + key"
                        autocomplete="off" />
                     {{ passenger_coupe_type.title }}
                  </label>
               </div>
            </div>

            <div class="div_btn">
               <span
                  @click="accept_data"
                  class="btn btn-block btn-close site-bg-main-color"
                  >تأیید</span
               >
            </div>
         </div>
      </div>
   </div>
</template>
<script>
export default {
   name: "passenger-count-box",
   props: ["form", "strategy"],
   data() {
      return {
         passengers_index: [
            {
               index: "adult",
               title: "بزرگسال",
               text: "(بزرگتر از ۱۲ سال)",
            },
            {
               index: "child",
               title: "کودک",
               text: "(بین 2 الی 12 سال)",
            },
            {
               index: "infant",
               title: "نوزاد",
               text: "(کوچکتر از 2 سال)",
            },
         ],
         passengers_seat_type: [
            {
               index: "women_only",
               title: "ویژه خواهران",
            },
            {
               index: "men_only",
               title: "ویژه برادران",
            },
            {
               index: "default",
               title: "مسافرین عادی",
            },
         ],
         passengers_coupe_type: [
            {
               index: true,
               title: "کوپه اختصاصی",
            },
            {
               index: false,
               title: "کوپه معمولی",
            },
         ],
      }
   },
   methods: {
      changeSeatType(type) {
         this.form[this.strategy].passengers_number.seat_type = type
      },
      changeCoupeType(type) {
         this.form[this.strategy].passengers_number.dedicated_coupe = type
      },
      canAdd(passenger_index, show_error = true) {
         let passenger_max = this.form[this.strategy].passengers_number.max
         let current_passenger_count =
            this.form[this.strategy].passengers_number[passenger_index].value
         let all_passengers_count = 0
         let all_passengers_index = ["adult", "child", "infant"]
         for (let item in all_passengers_index) {
            all_passengers_count +=
               this.form[this.strategy].passengers_number[
                  all_passengers_index[item]
               ].value
         }
         if (all_passengers_count <= passenger_max) {
            let child_count =
               this.form[this.strategy].passengers_number.child.value
            let adult_count =
               this.form[this.strategy].passengers_number.adult.value
            let infant_count =
               this.form[this.strategy].passengers_number.infant.value

            if (
               passenger_index !== "infant" ||
               child_count + adult_count > infant_count
            ) {
               return true
            } else {
               if (show_error) {
                  this.$swal({
                     icon: "error",
                     toast: true,
                     position: "bottom",
                     showConfirmButton: false,
                     timerProgressBar: true,
                     timer: 4000,
                     title: "جمع بزرگسال و کودک نباید از نوزاد بیشتر باشد.",
                  })
               }

               return false
            }
         } else {
            if (show_error) {
               this.$swal({
                  icon: "error",
                  toast: true,
                  position: "bottom",
                  showConfirmButton: false,
                  timer: 4000,
                  timerProgressBar: true,
                  title: "حداکثر تعداد مسافران " + passenger_max + " نفر است.",
               })
            }
            return false
         }
      },
      increaseCount(passenger_index) {
         if (this.canAdd(passenger_index)) {
            let current_passenger_count =
               this.form[this.strategy].passengers_number[passenger_index].value

            this.form[this.strategy].passengers_number[passenger_index].value =
               current_passenger_count + 1
         }
      },
      decreaseCount(passenger_index) {
         let current_passenger_count =
            this.form[this.strategy].passengers_number[passenger_index].value

         if (current_passenger_count > 0) {
            if (
               passenger_index !== "adult" ||
               this.form[this.strategy].passengers_number.adult.value > 1
            ) {
               this.form[this.strategy].passengers_number[
                  passenger_index
               ].value = current_passenger_count - 1
            }
         }
      },
      accept_data() {
         this.form[this.strategy].options.passengers_number = false
      },
   },
}
</script>