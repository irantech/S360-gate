<template>
   <div>
      <div class="content_main_app position-unset">
         <a href="/gds/app" class="logo">
            <img
               :src="client_data.project_files+`/icons/icon-512x512.png`"
               :alt="`logo`" />
         </a>

         <div class="search_box position-unset container">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
               <li
                  v-for="(service, index) in client_data.

                  client_services_detail"
                  class="nav-item"
                  :class="`order-` + service.order_number">
                  <a
                     class="nav-link"
                     :class="{active: service.order_number === '1' || (index === 0 && service.order_number === null)}"
                     :id="service.MainService.toLowerCase() + '-tab'"
                     data-toggle="tab"
                     :href="`#` + service.MainService.toLowerCase()"
                     role="tab"
                     :aria-controls="service.MainService.toLowerCase()"
                     aria-selected="true">
                     <h4>
                        <i
                           class="icon-tab icon-airplane"
                           v-html="icons[service.MainService.toLowerCase()]">
                        </i>
                        <span>{{ service.Title }}</span>
                     </h4>
                  </a>
               </li>
            </ul>
            <div class="tab-content position-unset" id="myTabContent">
               <div
                 v-for="(service, index) in client_data.client_services_detail"
                 :class="{'show active': service.order_number === '1' || (index === 0 && service.order_number === null)}"
                  class="tab-pane position-unset"
                  :id="service.MainService.toLowerCase()"
                  role="tabpanel"
                  :aria-labelledby="service.MainService.toLowerCase()+`-tab`">
                 <component
                   :main_url="client_data.online_url"
                   :is="service.MainService.toLowerCase()+`-tab`"></component>
               </div>
            </div>
         </div>

         <!--      <footer-section :page="pwa_page_data.index"></footer-section>-->
      </div>
   </div>
</template>
<script>
import flightTab from "./components/tabs/flight/index"
import hotelTab from "./components/tabs/hotel/index"
import tourTab from "./components/tabs/tour/index"
import trainTab from "./components/tabs/train/index"
import busTab from "./components/tabs/bus/index"
import insuranceTab from "./components/tabs/insurance/index"
import footerSection from "./../components/footer"

export default {
   name: "searchService",
   props: ["pwa_page_data"],
   components: {
      "flight-tab": flightTab,
      "hotel-tab": hotelTab,
      "tour-tab": tourTab,
      "train-tab": trainTab,
      "bus-tab": busTab,
      "insurance-tab": insuranceTab,
      "footer-section": footerSection,
   },
   created() {
      this.$store.dispatch("pwaGetClientData", this.api_gds_client_data())
   },
   computed: {
      client_data() {
         return this.$store.state.pwa_page
      },
   },

   data() {
      return {
         icons: {
            flight: "&#xe800;",
            hotel: "&#xe808;",
            tour: "&#xe809;",
            train: "&#xe803;",
            bus: "&#xe80c;",
            insurance: "&#xe80d;",
         },
         // main_url:window.location.hostname+'/gds/fa'
      }
   },
}
</script>
